-- Databricks notebook source
-- MAGIC %md-sandbox
-- MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
-- MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
-- MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
-- MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
-- MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
-- MAGIC     <span>Data Security & Governance Delivery Expert</span>
-- MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
-- MAGIC     <span>Design</span>
-- MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
-- MAGIC     <span style="font-weight:600; color:#eb1900;">Design Validation</span>
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
-- MAGIC   <img
-- MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
-- MAGIC     alt="Databricks Learning"
-- MAGIC   >
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC # Design Validation
-- MAGIC
-- MAGIC Recall that the ultimate goal is as follows: get all data from the Hive metastore into a new Unity Catalog metastore, and getting all your workloads to use it instead.
-- MAGIC
-- MAGIC There are a few different routes to get there. Each method addresses different sets of needs and operational constraints. In this lesson, we detail them all.
-- MAGIC
-- MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 8px; margin: 16px 0;">
-- MAGIC   <div style="display: flex; align-items: center; gap: 12px;">
-- MAGIC     <span style="font-size: 24px;">⚠️</span>
-- MAGIC     <div>
-- MAGIC       This notebook is not supported for execution on Databricks Academy provided workspaces. The material is intended to be a study guide, to be run in your own sandbox environments if you would like. Databricks Academy does not provide an account with a live HMS, administrator level access, or an AWS account, all of which would be required to perform all the activities in these notebooks.<p>
-- MAGIC       <strong>The notebooks flagged as labs in the agenda can be run in a Databricks Academy provided Vocareum workspace and allow you to put the concepts to practice.</strong>
-- MAGIC     </div>
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Learning Objectives
-- MAGIC
-- MAGIC By the end of this lesson, you will be able to:
-- MAGIC - Review and gain customer approval

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## A. Current State
-- MAGIC
-- MAGIC Begin by reviewing the results of the UCX upgrade assessment dashboard. These are created at the workspace level, so results should be reviewed for each applicable workspace.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ### A1. Asset Inventory
-- MAGIC
-- MAGIC Details that should be reviewed and validated include a complete inventory of:
-- MAGIC - HMS assets:
-- MAGIC   - schemas
-- MAGIC   - tables
-- MAGIC   - views
-- MAGIC   - access control lists (grants)
-- MAGIC - External tables, with data in:
-- MAGIC    - cloud storage
-- MAGIC    - DBFS mount point
-- MAGIC - Managed tables, with data in:
-- MAGIC    - DBFS root
-- MAGIC    - DBFS mount
-- MAGIC - DBFS mounts
-- MAGIC - Direct external locations
-- MAGIC - Local groups
-- MAGIC - Active jobs
-- MAGIC - Declarative pipelines 
-- MAGIC - Active clusters
-- MAGIC - Notebook/repos
-- MAGIC - ML Models/Feature Stores
-- MAGIC
-- MAGIC The tool will also provide a opinionated migration instructions which should also be reviewed with the customer.
-- MAGIC
-- MAGIC <div class="mermaid">
-- MAGIC flowchart LR
-- MAGIC subgraph WS_B["Workspace B"]
-- MAGIC direction LR
-- MAGIC subgraph ID_LAYOUT[" "]
-- MAGIC direction TB
-- MAGIC grpA["Group A"]
-- MAGIC grpB["Group B"]
-- MAGIC end
-- MAGIC subgraph DEV_LAYOUT[" "]
-- MAGIC direction TB
-- MAGIC nb1["Notebook"]
-- MAGIC repo1["Repo"]
-- MAGIC end
-- MAGIC subgraph RUN_LAYOUT[" "]
-- MAGIC direction TB
-- MAGIC wlA["Workload A"]
-- MAGIC wlB["Workload B"]
-- MAGIC wlC["Workload C"]
-- MAGIC end
-- MAGIC subgraph CMP_LAYOUT[" "]
-- MAGIC direction TB
-- MAGIC cA["Cluster A"]
-- MAGIC cB["Cluster B"]
-- MAGIC end
-- MAGIC subgraph HMS["Hive Metastore"]
-- MAGIC direction TB
-- MAGIC sA["Schema A"]
-- MAGIC sB["Schema B"]
-- MAGIC tA1@{ shape: div-rect, label: "Table A" }
-- MAGIC tB1@{ shape: div-rect, label: "Table B" }
-- MAGIC tA2@{ shape: div-rect, label: "Table A" }
-- MAGIC sA --- tA1
-- MAGIC sA --- tB1
-- MAGIC sB --- tA2
-- MAGIC end
-- MAGIC subgraph DBFS["DBFS"]
-- MAGIC direction TB
-- MAGIC dbfs_root["DBFS root<br/>/"]
-- MAGIC dbfs_mnt["DBFS mount<br/>/mnt/storage"]
-- MAGIC end
-- MAGIC end
-- MAGIC subgraph CLOUD_LAYOUT[" "]
-- MAGIC direction TB
-- MAGIC cloud1@{ shape: cloud, label: "Storage" }
-- MAGIC cloud2@{ shape: cloud, label: "Storage" }
-- MAGIC end
-- MAGIC grpA -->|USAGE| sA
-- MAGIC grpB -->|USAGE| sB
-- MAGIC wlA --> cA
-- MAGIC wlB --> cB
-- MAGIC wlC --> cB
-- MAGIC wlA --> nb1
-- MAGIC wlB --> repo1
-- MAGIC tA1 -->|"External location"| cloud1
-- MAGIC tA2 --> dbfs_mnt
-- MAGIC dbfs_mnt -->|"DBFS mount"| cloud2
-- MAGIC tB1 -->|"DBFS root"| dbfs_root
-- MAGIC classDef ws fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:2px
-- MAGIC classDef hmsLegacy fill:#E6E1D8,stroke:#1B3139,color:#1B3139,stroke-dasharray:6 4,stroke-width:2px
-- MAGIC classDef dbfsLegacy fill:#DDE6EC,stroke:#1B3139,color:#1B3139,stroke-dasharray:6 4,stroke-width:2px
-- MAGIC classDef invisible fill:transparent,stroke:transparent,color:transparent
-- MAGIC classDef identity fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
-- MAGIC classDef dev fill:#EEEDE9,stroke:#303F47,color:#1B3139,stroke-width:2px
-- MAGIC classDef workload fill:#00A972,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
-- MAGIC classDef compute fill:#98102A,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
-- MAGIC classDef schema fill:#EEEDE9,stroke:#303F47,color:#1B3139,stroke-width:2px
-- MAGIC classDef table fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
-- MAGIC classDef cloudBox fill:transparent,stroke:#2272B4,color:#1B3139,stroke-width:2px
-- MAGIC class WS_B ws
-- MAGIC class HMS hmsLegacy
-- MAGIC class DBFS dbfsLegacy
-- MAGIC class ID_LAYOUT,DEV_LAYOUT,RUN_LAYOUT,CMP_LAYOUT,CLOUD_LAYOUT invisible
-- MAGIC class grpA,grpB identity
-- MAGIC class dbfs_root,dbfs_mnt dev
-- MAGIC class nb1,repo1 table
-- MAGIC class wlA,wlB,wlC workload
-- MAGIC class cA,cB compute
-- MAGIC class sA,sB,tA1,tB1,tA2 schema
-- MAGIC class cloud1,cloud2 cloudBox
-- MAGIC </div>
-- MAGIC <script type="module">
-- MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
-- MAGIC </script>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A2. Compute Feature Usage
-- MAGIC
-- MAGIC Some feature usage will impact the migration effort. Review usage of features such as:
-- MAGIC - Init scripts and Library installation
-- MAGIC - Older runtimes and cluster access mode changes
-- MAGIC - ML runtime on shared clusters
-- MAGIC - User Defined Functions (UDFs)

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## B. Migration Considerations
-- MAGIC
-- MAGIC - Review requirements for Data Governance and Data management
-- MAGIC - Review access control patterns to manage users and groups
-- MAGIC - Review UC migration options
-- MAGIC    - In-place
-- MAGIC    - Parallel
-- MAGIC    - HMS Federation

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##C. Proposed State
-- MAGIC
-- MAGIC Review the proposed migration design with the customer and secure explicit approval. This includes walkthroughs of the catalog layout, access patterns, and intended outcomes.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C1. Technical Validation
-- MAGIC
-- MAGIC - Validate namespace (`catalog`.`schema`.`table`) design.
-- MAGIC - Confirm that external storage locations are registered correctly and legacy DBFS mounts are replaced with UC external location patterns.
-- MAGIC - Check compute resource configuration for UC compatibility and enforce UC-specific policies on clusters.
-- MAGIC - Validate encryption policies and storage credentials.
-- MAGIC - Perform pre-migration validation steps such as access mapping, service principal configuration, and existence of external locations and schemas.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C2. Governance Model Validation
-- MAGIC
-- MAGIC - Confirm that data governance requirements (catalog separation, schema ownership, access control patterns) are mapped into UC design.
-- MAGIC - Ensure user/group roles and access controls are defined and modeled as needed for the customer’s environment.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C3. Migration Readiness Checks
-- MAGIC
-- MAGIC - Run assessment tools (UCX) for inventory mapping and compatibility checks.
-- MAGIC - Use migration mapping checklists to verify all dependencies and migration scope are covered.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C4. Testing and Validation Steps
-- MAGIC
-- MAGIC - Validate that UC-enabled clusters/warehouses can access required resources.
-- MAGIC - Perform test reads/writes and ensure workloads function as expected in the UC environment.
-- MAGIC - Use data validation tools to ensure data and schema consistency between HMS and UC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>