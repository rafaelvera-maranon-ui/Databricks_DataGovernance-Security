# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span>Data Security & Governance Delivery Expert</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span>Cutover</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Cutover Execution</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Cutover Execution
# MAGIC
# MAGIC With migration complete and workloads running successfully on Unity Catalog, the final step is retiring the HMS and DBFS in all workspaces. This lesson covers the decommissioning process, including data archival, connector shutdown, and formal engagement closure.
# MAGIC
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 8px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: center; gap: 12px;">
# MAGIC     <span style="font-size: 24px;">⚠️</span>
# MAGIC     <div>
# MAGIC       This notebook is not supported for execution on Databricks Academy provided workspaces. The material is intended to be a study guide, to be run in your own sandbox environments if you would like. Databricks Academy does not provide an account with a live HMS, administrator level access, or an AWS account, all of which would be required to perform all the activities in these notebooks.<p>
# MAGIC       <strong>The notebooks flagged as labs in the agenda can be run in a Databricks Academy provided Vocareum workspace and allow you to put the concepts to practice.</strong>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lesson, you will be able to:
# MAGIC
# MAGIC - Execute a controlled HMS/DBFS decommissioning plan
# MAGIC - Archive tables, stages, and metadata for compliance
# MAGIC - Shut down connectors and integrations pointing to HMS
# MAGIC - Conduct final stakeholder review and close the migration engagement

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## A. Decommissioning Timeline
# MAGIC
# MAGIC Decommissioning should follow a phased approach with validation gates at each stage.
# MAGIC
# MAGIC <div class="mermaid">
# MAGIC gantt
# MAGIC     title HMS/DBFS Decommissioning Timeline
# MAGIC     dateFormat YYYY-MM-DD
# MAGIC     axisFormat %W
# MAGIC     tickInterval 1week
# MAGIC     section Validation
# MAGIC     HMS Federation           :done, v1, 2025-01-05, 1w
# MAGIC     section Wind-Down
# MAGIC     HMS Read-Only                :active, r1, after v1, 2w
# MAGIC     Archive & Backup                :a1, after r1, 1w
# MAGIC     section Shutdown
# MAGIC     HMS Deprecated              :crit, c1, after a1, 1w
# MAGIC     HMS Disabled              :milestone, s1, after c1, 0d
# MAGIC </div>
# MAGIC
# MAGIC <script type="module"> import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC | Phase | Duration | Activities |
# MAGIC |-------|----------|------------|
# MAGIC | **Parallel Run Complete** | Week 0 | Confirm all workloads validated on UC |
# MAGIC | **Read-Only Period** | Weeks 1-2 | HMS set to read-only; monitor for access attempts |
# MAGIC | **Archive & Backup** | Week 3 | Export data, metadata, and query history |
# MAGIC | **HMS Deprecated** | Week 4 | Rename schemas |
# MAGIC | **HMS Disabled** | Week 5+ | Disable HMS from all workspaces; retain archives per policy |

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Pre-Decommission Validation
# MAGIC
# MAGIC Before beginning decommissioning, confirm all migration success criteria are met.
# MAGIC
# MAGIC | Validation | Owner |
# MAGIC |------------|-------|
# MAGIC | All tables migrated and row counts validated | Data Engineering |
# MAGIC | All pipelines running successfully on Databricks | Data Engineering |
# MAGIC | BI tools reconnected and dashboards functional | Analytics |
# MAGIC | Data quality monitors active with no critical alerts | Data Engineering |
# MAGIC | User acceptance testing signed off | Business Stakeholders |
# MAGIC | Performance SLAs met or exceeded | Data Engineering |
# MAGIC | Security and compliance review complete | Security |
# MAGIC | Runbooks and documentation delivered | Project Team |

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Archive and Backup
# MAGIC
# MAGIC Before deprecating HMS, archive critical data and metadata for compliance and potential rollback.
# MAGIC
# MAGIC ### What to Archive
# MAGIC
# MAGIC | Asset | Archive Method | Retention |
# MAGIC |-------|----------------|-----------|
# MAGIC | **Table data** | `COPY INTO` to cloud storage (Parquet) | Per data retention policy |
# MAGIC | **Stage contents** | Download or copy to archive bucket | 90 days minimum |
# MAGIC | **Query history** | Export from SQL warehouses | 1 year |
# MAGIC | **User/role definitions** | Export grants and role hierarchy | Permanent |

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Connector Shutdown
# MAGIC
# MAGIC Systematically disable all integrations pointing to HMS.
# MAGIC
# MAGIC | Integration Type | Shutdown Action |
# MAGIC |------------------|-----------------|
# MAGIC | **BI Tools** (Tableau, Power BI, Looker) | Remove any HMS connections; confirm UC connections active |
# MAGIC | **ETL/ELT Tools** (Fivetran, Airbyte, dbt) | Disable HMS destinations; verify UC targets |
# MAGIC | **Application connections** | Update connection strings; rotate credentials |
# MAGIC | **Scheduled tasks** | Suspend all jobs accessing HMS |
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 8px; margin: 16px 0;">
# MAGIC     <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC         <span style="font-size: 24px;">⚠️</span>
# MAGIC         <div>
# MAGIC             <strong style="color: #e65100; font-size: 1.1em;">Monitor Before Shutdown</strong>
# MAGIC             <p style="margin: 8px 0 0 0; color: #333;">During the read-only period, monitor access logs to identify any overlooked integrations or users still attempting to connect. Address these before proceeding with deprecation.</p>
# MAGIC         </div>
# MAGIC     </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Final Stakeholder Review
# MAGIC
# MAGIC Conduct a formal review with stakeholders to confirm migration success and close the engagement.
# MAGIC
# MAGIC ### Success Metrics to Present
# MAGIC
# MAGIC - Tables migrated and validated
# MAGIC - Pipelines operational on UC
# MAGIC - Performance comparison (HMS vs UC)
# MAGIC - User adoption and feedback

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## F. Recap
# MAGIC
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 16px 20px; border-radius: 8px; margin: 16px 0;">
# MAGIC     <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC         <span style="font-size: 24px;">✅</span>
# MAGIC         <div>
# MAGIC             <strong style="color: #2e7d32; font-size: 1.1em;">Decommissioning Checklist</strong>
# MAGIC             <ul style="margin: 8px 0 0 0; color: #333; padding-left: 20px;">
# MAGIC                 <li>All migration success criteria validated</li>
# MAGIC                 <li>HMS data and metadata archived</li>
# MAGIC                 <li>Query and access history exported</li>
# MAGIC                 <li>All connectors and integrations disabled</li>
# MAGIC                 <li>Final stakeholder review completed</li>
# MAGIC                 <li>Sign-off obtained from business stakeholders</li>
# MAGIC                 <li>HMS disabled</li>
# MAGIC                 <li>Migration engagement formally closed</li>
# MAGIC             </ul>
# MAGIC         </div>
# MAGIC     </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>