# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span>Data Security & Governance Delivery Expert</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Setup</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Agenda
# MAGIC
# MAGIC | Section | Time | Lecture | Demo | Lab |
# MAGIC |:----:|-----|-----|-----|-----|
# MAGIC | [Account Configuration]($./1 - Account Configuration) | 10 min |✓|||
# MAGIC | [Managing Metastores and Compute]($./2 - Managing Metastores and Compute) | 20 min ||✓||
# MAGIC | [Storage and Credential Setup]($./3 - Storage and Credential Setup) | 10 min |✓|||
# MAGIC | [Namespace Bootstrapping]($./4 - Namespace Bootstrapping) | 10 min |✓|||
# MAGIC | [Creating and Managing Catalogs and Storage]($./5 - Creating and Managing Catalogs and Storage) | 15 min ||✓||
# MAGIC | [Validation and Sign-off]($./6 - Validation and Sign-off) | 10 min |✓|||
# MAGIC | [Getting Started with the Migration]($./7 - Getting Started with the Migration Lab) | 15 min |||✓|

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>